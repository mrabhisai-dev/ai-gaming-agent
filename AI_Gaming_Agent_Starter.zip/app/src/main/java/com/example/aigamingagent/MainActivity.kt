package com.example.aigamingagent

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var instruction: EditText
    private lateinit var actionChoice: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "AI Gaming Agent"
            textSize = 26f
        }
        root.addView(title)

        val note = TextView(this).apply {
            text = "शुरुआती प्रोटोटाइप • पहले Accessibility अनुमति दें"
            textSize = 14f
            setPadding(0, 12, 0, 18)
        }
        root.addView(note)

        instruction = EditText(this).apply {
            hint = "अपने गेम के नियम लिखें (अभी केवल नोट के रूप में)"
            minLines = 3
            gravity = Gravity.TOP
        }
        root.addView(instruction, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        actionChoice = Spinner(this)
        val options = listOf("Tap repeatedly", "Swipe left", "Swipe right")
        actionChoice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        root.addView(actionChoice)

        val permissionButton = Button(this).apply {
            text = "Accessibility Settings खोलें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(permissionButton)

        val startButton = Button(this).apply {
            text = "Start"
            setOnClickListener {
                val prefs = getSharedPreferences(GameControlService.PREFS, MODE_PRIVATE)
                prefs.edit()
                    .putString(GameControlService.KEY_ACTION, actionChoice.selectedItem.toString())
                    .putString(GameControlService.KEY_INSTRUCTION, instruction.text.toString())
                    .putBoolean(GameControlService.KEY_RUNNING, true)
                    .apply()
                GameControlService.requestRun = true
                status.text = "Start अनुरोध भेजा गया। गेम स्क्रीन पर जाएँ।"
            }
        }
        root.addView(startButton)

        val stopButton = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                getSharedPreferences(GameControlService.PREFS, MODE_PRIVATE)
                    .edit().putBoolean(GameControlService.KEY_RUNNING, false).apply()
                GameControlService.requestRun = false
                status.text = "रोक दिया गया।"
            }
        }
        root.addView(stopButton)

        status = TextView(this).apply {
            text = "स्थिति: रुका हुआ"
            textSize = 16f
            setPadding(0, 14, 0, 0)
        }
        root.addView(status)

        val warning = TextView(this).apply {
            text = "ध्यान दें: यह संस्करण गेम को देख/समझ नहीं सकता। यह केवल चुनी हुई क्रिया दोहराता है। पहले किसी साधारण offline game में जाँचें।"
            setPadding(0, 18, 0, 0)
        }
        root.addView(warning)

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
