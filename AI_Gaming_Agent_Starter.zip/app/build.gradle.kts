plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.aigamingagent"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.aigamingagent"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
    }
}
