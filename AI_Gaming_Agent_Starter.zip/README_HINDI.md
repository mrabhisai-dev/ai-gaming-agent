# AI Gaming Agent — Android Starter (मुफ़्त शुरुआती प्रोजेक्ट)

यह Android Studio के लिए एक शुरुआती Kotlin प्रोजेक्ट है। यह **पूरा AI नहीं** है और अभी किसी भी गेम को देखकर खुद रणनीति नहीं सीखता। इसमें:
- निर्देश लिखने के लिए एक साधारण स्क्रीन
- Android Accessibility Service के जरिए user-approved tap/swipe करने का आधार
- Start/Stop नियंत्रण

## ज़रूरी बातें
1. Android Studio वाला कंप्यूटर इस प्रोजेक्ट को APK में build करने का सबसे आसान तरीका है। सिर्फ मोबाइल पर APK build करना अलग और सीमित प्रक्रिया है।
2. Accessibility permission संवेदनशील होती है। इसे केवल अपने डिवाइस पर, अपनी अनुमति से चालू करें।
3. यह starter गेम की स्क्रीन की वस्तुओं को पहचानता नहीं है। किसी खास गेम के लिए vision/decision logic अलग से बनाना होगा।
4. इसे ऑनलाइन गेम में cheating, anti-cheat bypass, या दूसरे खिलाड़ियों को नुकसान पहुँचाने के लिए न इस्तेमाल करें।

## Build
- Android Studio में इस फ़ोल्डर को खोलें।
- Gradle sync पूरा होने दें।
- Run दबाकर अपने Android फोन पर install करें।
- ऐप में Accessibility settings खोलें और **AI Gaming Agent** service चालू करें।
- ऐप पर लौटकर अपना गेम-नियम चुनें और Start दबाएँ।
- Stop दबाकर कभी भी रोकें।

## मौजूदा prototype का व्यवहार
- `Tap repeatedly`: स्क्रीन के बीच में tap करने की कोशिश करता है, लगभग हर 1.2 सेकंड में।
- `Swipe left/right`: चुनी हुई दिशा में swipe करता है, लगभग हर 1.8 सेकंड में।
- लिखे गए natural-language निर्देश अभी स्वतः समझे नहीं जाते; action चुनना पड़ता है।

अगला चरण: गेम का नाम और गेम का screenshot/व्यवहार मिलने पर उसी गेम के लिए स्क्रीन पहचान और निर्णय प्रणाली बनाई जा सकती है।
